package br.dcx.ufpb.fr;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepositoAddController implements ActionListener {
    private BebidasDP bebida;
    private JFrame janelaPrincipal;
    public DepositoAddController(BebidasDP bebida, JFrame janela){
        this.bebida= bebida;
        this.janelaPrincipal= janela;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String nomeDaBebida = JOptionPane.showInputDialog(janelaPrincipal,
                "Qual o nome da bebida");
        int quantBebidas = Integer.parseInt(JOptionPane.showInputDialog(janelaPrincipal,
                "Informe a(s) quantidade(s) necessária(s) "));
        double precoDaBebida= Integer.parseInt(JOptionPane.showInputDialog(janelaPrincipal,
                "Imforme o preço" ));
        boolean cadastrou = bebida.cadastraBebidas(nomeDaBebida,quantBebidas,precoDaBebida);
        if (cadastrou){
            JOptionPane.showMessageDialog(janelaPrincipal,
                    "Bebida Cadastrada");
        } else {
            JOptionPane.showMessageDialog(janelaPrincipal,
                    "Bebida não foi cadastrada  " +
                            "Verifique se já não existia");
        }


    }
}
