package br.dcx.ufpb.fr;

import java.io.IOException;
import java.util.HashMap;
import java.util.*;
import java.util.concurrent.Callable;

public class DepositoFR implements BebidasDP{
    private Map<String, Bebidas> bebidas;
    private GravadorDeDados gravador = new GravadorDeDados();

    public DepositoFR(){
        this.bebidas = new HashMap<>();
        recuperaDados();

    }
    public void salvarDados(){
        try{
            this.gravador.salvarBebidas(this.bebidas);
        }catch (Exception e){
            System.err.println(e.getMessage());
        }
    }

    public void recuperaDados(){
        try {
            this.bebidas= this.gravador.recuperaBebidas();
        }catch (IOException e){
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean cadastraBebidas(String nomeDaBebida, int quantBebidas, double precoDaUnidade) {
        if( !bebidas.containsKey(nomeDaBebida)){
            this.bebidas.put(nomeDaBebida, new Bebidas(nomeDaBebida, precoDaUnidade, quantBebidas);
            return true;
        }else{
            return false;
        }
    }

    @Override
    public ArrayList<Bebidas> pesquisaBebidas(String nomeDaBebida, double precoDaUnidade) {
        Collection<Bebidas> BBsAchadas = new ArrayList<>();
        for (Bebidas b: this.bebidas.values()){
            if(b.getNomeDaBB() == nomeDaBebida && b.getPrecoDaBB() == precoDaUnidade){
                BBsAchadas.add(b);
            }
        }
        return (ArrayList<Bebidas>) BBsAchadas;
    }

    @Override
    public boolean removeBebidas(String nomeDaBebida) {
        if(this.bebidas.containsKey(nomeDaBebida)){
            this.bebidas.remove(nomeDaBebida);
            return true;
        }else{
            return false;
        }
    }
}
