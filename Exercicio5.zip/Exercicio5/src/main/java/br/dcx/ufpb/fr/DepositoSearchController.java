package br.dcx.ufpb.fr;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

public class DepositoSearchController implements ActionListener {
    private BebidasDP bebida;
    private JFrame janelaPrincipal;
    public DepositoSearchController(BebidasDP bebida, JFrame janela){
        this.bebida=bebida;
        this.janelaPrincipal=janela;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String nomeDaBebida= JOptionPane.showInputDialog(janelaPrincipal, "Imforme o nome da bebida");
        double precoDaBebida= Double.parseDouble(JOptionPane.showInputDialog(janelaPrincipal,"Imforme o preço da bebida"));
        Collection<Bebidas> bebidas = bebida.pesquisaBebidas(nomeDaBebida,precoDaBebida);
        if(bebidas.size()>0){
            JOptionPane.showInputDialog(janelaPrincipal."Bebidas encontradas:");
            for(Bebidas b: bebidas){
                JOptionPane.showInputDialog(janelaPrincipal,b.toString());
            }
        }else{
            JOptionPane.showInputDialog(janelaPrincipal,"Não foi encontrado nenhuma bebidas");
        }

    }
}
