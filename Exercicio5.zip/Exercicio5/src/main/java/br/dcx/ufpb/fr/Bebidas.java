package br.dcx.ufpb.fr;

import java.io.Serializable;
import java.util.Objects;

public class Bebidas implements Serializable {
    private String nomeDaBB;
    double precoDaBB;
    int quantBebidas;

    public Bebidas(String nomeDaBB, double precoDaBB, int quantBebidas) {
        this.nomeDaBB = nomeDaBB;
        this.precoDaBB = precoDaBB;
        this.quantBebidas= quantBebidas;
    }

    public int getQuantBebidas() {
        return quantBebidas;
    }

    public void setQuantBebidas(int quantBebidas) {
        this.quantBebidas = quantBebidas;
    }

    public String getNomeDaBB() {
        return nomeDaBB;
    }

    public void setNomeDaBB(String nomeDaBB) {
        this.nomeDaBB = nomeDaBB;
    }

    public double getPrecoDaBB() {
        return precoDaBB;
    }

    public void setPrecoDaBB(double precoDaBB) {
        this.precoDaBB = precoDaBB;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Bebidas bebidas)) return false;
        return Double.compare(bebidas.precoDaBB, precoDaBB) == 0 && quantBebidas == bebidas.quantBebidas && Objects.equals(nomeDaBB, bebidas.nomeDaBB);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nomeDaBB, precoDaBB, quantBebidas);
    }

    @Override
    public String toString() {
        return "Bebidas{" +
                "nomeDaBB='" + nomeDaBB + '\'' +
                ", precoDaBB=" + precoDaBB +
                ", quantBebidas=" + quantBebidas +
                '}';
    }
}
