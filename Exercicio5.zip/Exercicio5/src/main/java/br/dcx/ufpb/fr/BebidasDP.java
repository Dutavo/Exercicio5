package br.dcx.ufpb.fr;

import java.util.ArrayList;
import java.util.Collection;

public interface BebidasDP {
    public boolean cadastraBebidas(String nomeDaBebida, int quantBebidas, double precoDaUnidade);
    public Collection<Bebidas> pesquisaBebidas(String nomeDaBebida, double precoDaUnidade);
    public boolean removeBebidas(String nomeDaBebida);


}
