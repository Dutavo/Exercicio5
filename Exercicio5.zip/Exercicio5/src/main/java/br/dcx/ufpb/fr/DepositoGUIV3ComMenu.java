package br.dcx.ufpb.fr;

import javax.swing.*;
import java.awt.*;

public class DepositoGUIV3ComMenu extends JFrame {
    JLabel linha1, linha2;


}
