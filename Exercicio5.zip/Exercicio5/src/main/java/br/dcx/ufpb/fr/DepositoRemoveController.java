package br.dcx.ufpb.fr;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepositoRemoveController implements ActionListener {
    private  BebidasDP bebida;
    private JFrame janelaprincipal;

    public DepositoRemoveController(BebidasDP bebida, JFrame janela){
        this.bebida= bebida;
        this.janelaprincipal= janela;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String nomeDaBebida= JOptionPane.showInputDialog(janelaprincipal,"Qual o nome da Bebida");
        boolean removeu= bebida.removeBebidas(nomeDaBebida);
        if(removeu){
            JOptionPane.showInputDialog(janelaprincipal,"Bebida removida com sucesso");
        }else{
            JOptionPane.showInputDialog(janelaprincipal,"Bebida não foi encontrada." + "Operação não realizada");
        }
    }
}
